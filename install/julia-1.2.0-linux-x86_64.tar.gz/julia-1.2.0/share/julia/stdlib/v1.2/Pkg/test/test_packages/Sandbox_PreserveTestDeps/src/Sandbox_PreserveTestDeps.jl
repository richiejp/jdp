module Sandbox_PreserveTestDeps

greet() = print("Hello World!")

end # module
