module Foo

greet() = print("Hello World!")

end # module
