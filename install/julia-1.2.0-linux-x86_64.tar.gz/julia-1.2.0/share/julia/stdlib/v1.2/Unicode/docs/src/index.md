# Unicode

```@meta
DocTestSetup = :(using Unicode)
```

```@docs
Unicode.isassigned
Unicode.normalize
Unicode.graphemes
```

```@meta
DocTestSetup = nothing
```
